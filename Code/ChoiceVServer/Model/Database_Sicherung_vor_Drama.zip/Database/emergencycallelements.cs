﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class emergencycallelements
    {
        public long id { get; set; }
        public int calltype { get; set; }
        public int severity { get; set; }
        public DateTime time { get; set; }
        public string position { get; set; }
        public int charid { get; set; }
        public string charname { get; set; }
        public int isanonymous { get; set; }
        public string message { get; set; }
        public int ended { get; set; }
    }
}
