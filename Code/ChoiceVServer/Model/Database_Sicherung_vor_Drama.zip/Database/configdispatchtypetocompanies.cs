﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configdispatchtypetocompanies
    {
        public int type { get; set; }
        public int companyid { get; set; }
    }
}
