﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configweaponparts
    {
        public int id { get; set; }
        public int weaponPartType { get; set; }
        public string gtaComponent { get; set; }
        public string weaponName { get; set; }
        public int weaponType { get; set; }
    }
}
