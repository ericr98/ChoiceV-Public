﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configdoorgroups
    {
        public string identifier { get; set; }
        public string description { get; set; }
        public int crackAble { get; set; }
    }
}
