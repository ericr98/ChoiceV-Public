﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configitemanimations
    {
        public configitemanimations()
        {
            configinteractionpositions = new HashSet<configinteractionpositions>();
            configitems = new HashSet<configitems>();
        }

        public int id { get; set; }
        public string identifier { get; set; }
        public string modelHash { get; set; }
        public string position { get; set; }
        public string rotation { get; set; }
        public string dict { get; set; }
        public string name { get; set; }
        public int duration { get; set; }
        public int bone { get; set; }
        public int flag { get; set; }

        public virtual ICollection<configinteractionpositions> configinteractionpositions { get; set; }
        public virtual ICollection<configitems> configitems { get; set; }
    }
}
