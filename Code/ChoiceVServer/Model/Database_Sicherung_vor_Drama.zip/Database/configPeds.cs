﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configPeds
    {
        public int id { get; set; }
        public string model { get; set; }
        public float x { get; set; }
        public float y { get; set; }
        public float z { get; set; }
        public float heading { get; set; }
        public string interactionEvent { get; set; }
        public string additionalInfo { get; set; }
    }
}
