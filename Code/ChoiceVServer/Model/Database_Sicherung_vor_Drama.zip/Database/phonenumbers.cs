﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class phonenumbers
    {
        public phonenumbers()
        {
            phonecalllist = new HashSet<phonecalllist>();
            phonechatmessages = new HashSet<phonechatmessages>();
            phonechatsnumber1Navigation = new HashSet<phonechats>();
            phonechatsnumber2Navigation = new HashSet<phonechats>();
            phonecontacts = new HashSet<phonecontacts>();
        }

        public long number { get; set; }
        public string comment { get; set; }

        public virtual ICollection<phonecalllist> phonecalllist { get; set; }
        public virtual ICollection<phonechatmessages> phonechatmessages { get; set; }
        public virtual ICollection<phonechats> phonechatsnumber1Navigation { get; set; }
        public virtual ICollection<phonechats> phonechatsnumber2Navigation { get; set; }
        public virtual ICollection<phonecontacts> phonecontacts { get; set; }
    }
}
