﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configinjuriestoitems
    {
        public int injuryId { get; set; }
        public int itemId { get; set; }
        public int order { get; set; }

        public virtual configinjuries injury { get; set; }
        public virtual configitems item { get; set; }
    }
}
