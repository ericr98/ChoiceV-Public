﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configorderableelement
    {
        public int elementId { get; set; }
        public string alterDisplayName { get; set; }
        public string elementClass { get; set; }
    }
}
