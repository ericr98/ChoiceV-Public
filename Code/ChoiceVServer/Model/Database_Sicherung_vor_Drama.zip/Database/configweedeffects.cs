﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configweedeffects
    {
        public int id { get; set; }
        public string type { get; set; }
        public string effect { get; set; }
        public double strength { get; set; }
        public double length { get; set; }
    }
}
