﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configrentablecars
    {
        public int id { get; set; }
        public string model { get; set; }
        public string showName { get; set; }
        public int price { get; set; }
    }
}
