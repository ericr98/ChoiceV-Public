﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configbeardstyles
    {
        public int id { get; set; }
        public string name { get; set; }
        public decimal cost { get; set; }
        public int gtaId { get; set; }
    }
}
