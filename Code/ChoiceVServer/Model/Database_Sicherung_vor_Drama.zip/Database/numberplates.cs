﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class numberplates
    {
        public int Id { get; set; }
        public string index { get; set; }
    }
}
