﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configchairs
    {
        public string modelHash { get; set; }
        public float zOffset { get; set; }
        public float xyOffset { get; set; }
    }
}
