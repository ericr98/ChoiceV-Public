﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class jobannouncements
    {
        public int id { get; set; }
        public int ownerId { get; set; }
        public string title { get; set; }
        public string shortDescription { get; set; }
        public string message { get; set; }
        public string phoneNumber { get; set; }
        public DateTime expireDate { get; set; }
    }
}
