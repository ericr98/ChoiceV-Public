﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class banklogs
    {
        public int id { get; set; }
        public DateTime logdate { get; set; }
        public int eventType { get; set; }
        public int raisedByCharId { get; set; }
        public int fromAccount { get; set; }
        public int toAccount { get; set; }
        public string message { get; set; }
    }
}
