﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configgarages
    {
        public configgarages()
        {
            configgaragespawnspots = new HashSet<configgaragespawnspots>();
        }

        public int id { get; set; }
        public string name { get; set; }
        public string position { get; set; }
        public string rotation { get; set; }
        public int type { get; set; }
        public int ownerType { get; set; }
        public int ownerId { get; set; }
        public int slots { get; set; }

        public virtual ICollection<configgaragespawnspots> configgaragespawnspots { get; set; }
    }
}
