﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class carrents
    {
        public int id { get; set; }
        public int modelId { get; set; }
        public int charId { get; set; }
        public int vehicleId { get; set; }
        public string carName { get; set; }
        public string showName { get; set; }
        public DateTime rentalDate { get; set; }
        public int rentalTime { get; set; }
        public int rentalTimePaid { get; set; }
    }
}
