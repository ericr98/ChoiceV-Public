﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class vehiclesmodel
    {
        public vehiclesmodel()
        {
            vehiclesseat = new HashSet<vehiclesseat>();
        }

        public int id { get; set; }
        public DateTime createDate { get; set; }
        public int Model { get; set; }
        public string ModelName { get; set; }
        public int Class { get; set; }
        public int Seats { get; set; }
        public string Trunk { get; set; }
        public string Motor { get; set; }
        public int InventorySize { get; set; }
        public float FuelMax { get; set; }
        public float FuelPerKm { get; set; }
        public float FuelPerMin { get; set; }
        public int FuelType { get; set; }
        public string StartPoint { get; set; }
        public string EndPoint { get; set; }
        public float EnginePerKm { get; set; }
        public float WheelPerKm { get; set; }
        public float PowerMultiplier { get; set; }
        public float MaxSpeed { get; set; }
        public int megaphonerange { get; set; }
        public string Extras { get; set; }
        public int Locked { get; set; }
        public int EmergencyType { get; set; }

        public virtual ICollection<vehiclesseat> vehiclesseat { get; set; }
    }
}
