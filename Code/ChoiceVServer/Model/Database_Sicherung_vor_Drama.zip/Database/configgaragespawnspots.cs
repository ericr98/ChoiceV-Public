﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configgaragespawnspots
    {
        public int id { get; set; }
        public int garageId { get; set; }
        public float width { get; set; }
        public float height { get; set; }
        public string spawnposition { get; set; }
        public string spawnrotation { get; set; }

        public virtual configgarages garage { get; set; }
    }
}
