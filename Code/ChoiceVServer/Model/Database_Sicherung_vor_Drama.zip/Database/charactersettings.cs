﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class charactersettings
    {
        public int characterid { get; set; }
        public double hudtop { get; set; }
        public double hudleft { get; set; }

        public virtual characters character { get; set; }
    }
}
