﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configanalysespots
    {
        public int id { get; set; }
        public string position { get; set; }
        public float width { get; set; }
        public float height { get; set; }
        public float rotation { get; set; }
        public int trackVehicles { get; set; }
        public string codeItem { get; set; }
        public DateTime? analyseEnd { get; set; }
        public int inventoryId { get; set; }
        public string data { get; set; }
    }
}
