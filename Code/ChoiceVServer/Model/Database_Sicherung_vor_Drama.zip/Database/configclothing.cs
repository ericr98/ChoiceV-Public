﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configclothing
    {
        public int ID { get; set; }
        public int componentid { get; set; }
        public int drawableid { get; set; }
        public string name { get; set; }
        public string gender { get; set; }
        public decimal price { get; set; }
        public int textureAmount { get; set; }
        public int additionalInfo { get; set; }
        public int neededShirt { get; set; }
    }
}
