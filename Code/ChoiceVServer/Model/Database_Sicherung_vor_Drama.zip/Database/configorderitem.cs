﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configorderitem
    {
        public int orderableItemId { get; set; }
        public int itemType { get; set; }
        public int itemId { get; set; }
        public int ammount { get; set; }
        public int deliveryTimespan { get; set; }
        public int deliveryWeekday { get; set; }
        public sbyte anyoneOrderable { get; set; }
        public decimal pricePerUnit { get; set; }
        public int bulkSize { get; set; }
    }
}
