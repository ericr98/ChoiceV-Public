﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configblips
    {
        public int id { get; set; }
        public string name { get; set; }
        public int sprite { get; set; }
        public int colorId { get; set; }
        public string position { get; set; }
    }
}
