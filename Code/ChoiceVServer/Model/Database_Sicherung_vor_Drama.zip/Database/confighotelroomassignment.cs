﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class confighotelroomassignment
    {
        public int buildingid { get; set; }
        public int roomid { get; set; }
    }
}
