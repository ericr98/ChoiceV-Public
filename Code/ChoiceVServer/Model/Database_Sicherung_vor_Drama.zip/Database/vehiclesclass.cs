﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class vehiclesclass
    {
        public int id { get; set; }
        public DateTime createDate { get; set; }
        public int Class { get; set; }
        public string ClassName { get; set; }
        public int InventorySize { get; set; }
        public float FuelMax { get; set; }
        public float FuelPerKm { get; set; }
        public float FuelPerMin { get; set; }
        public int FuelType { get; set; }
        public float EnginePerKm { get; set; }
        public float WheelPerKm { get; set; }
    }
}
