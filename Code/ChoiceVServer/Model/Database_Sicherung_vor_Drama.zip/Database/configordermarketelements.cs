﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configordermarketelements
    {
        public int marketElementId { get; set; }
        public int companyId { get; set; }
        public int elementId { get; set; }
        public int bulkCount { get; set; }
        public decimal pricePerUnit { get; set; }
        public int deliveryTimespan { get; set; }
        public int deliveryStartDayOfWeek { get; set; }
        public string elementImage { get; set; }
        public string elementWebsite { get; set; }
    }
}
