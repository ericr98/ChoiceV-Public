﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class emergencycontrolcentreworkers
    {
        public int charid { get; set; }
    }
}
