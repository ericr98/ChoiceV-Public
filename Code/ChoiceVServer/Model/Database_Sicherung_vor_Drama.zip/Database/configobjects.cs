﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configobjects
    {
        public int id { get; set; }
        public string modelName { get; set; }
        public string modelHash { get; set; }
        public string codeFunction { get; set; }
        public string info { get; set; }
    }
}
