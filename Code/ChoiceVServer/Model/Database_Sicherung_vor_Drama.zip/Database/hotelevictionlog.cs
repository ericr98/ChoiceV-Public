﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class hotelevictionlog
    {
        public int id { get; set; }
        public DateTime evictiondate { get; set; }
        public int bookingid { get; set; }
        public int evictedchar { get; set; }
        public string reason { get; set; }
    }
}
