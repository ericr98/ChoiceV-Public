﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class phonecalllist
    {
        public int id { get; set; }
        public long from { get; set; }
        public long to { get; set; }
        public DateTime date { get; set; }
        public int missed { get; set; }
        public int _checked { get; set; }

        public virtual phonenumbers fromNavigation { get; set; }
    }
}
