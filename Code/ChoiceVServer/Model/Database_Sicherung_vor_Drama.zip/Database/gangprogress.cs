﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class gangprogress
    {
        public int gangid { get; set; }
        public int weedprogress { get; set; }
        public int cocaineprogress { get; set; }
        public int xpprogress { get; set; }
        public int ganglevel { get; set; }
    }
}
