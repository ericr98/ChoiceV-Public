﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configanimations
    {
        public configanimations()
        {
            configbeds = new HashSet<configbeds>();
            configcollectjobtasks = new HashSet<configcollectjobtasks>();
            configdeliverjobtasks = new HashSet<configdeliverjobtasks>();
            configinteractionpositions = new HashSet<configinteractionpositions>();
        }

        public int id { get; set; }
        public string identifier { get; set; }
        public string showName { get; set; }
        public string dict { get; set; }
        public string name { get; set; }
        public int duration { get; set; }
        public int flag { get; set; }
        public int shown { get; set; }
        public string group { get; set; }

        public virtual ICollection<configbeds> configbeds { get; set; }
        public virtual ICollection<configcollectjobtasks> configcollectjobtasks { get; set; }
        public virtual ICollection<configdeliverjobtasks> configdeliverjobtasks { get; set; }
        public virtual ICollection<configinteractionpositions> configinteractionpositions { get; set; }
    }
}
