﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class ownedcharacteraccessoires
    {
        public int charId { get; set; }
        public int componentId { get; set; }
        public int drawableId { get; set; }
        public int textureId { get; set; }
        public string name { get; set; }
    }
}
