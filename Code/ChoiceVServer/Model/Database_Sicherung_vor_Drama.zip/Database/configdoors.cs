﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configdoors
    {
        public int id { get; set; }
        public string position { get; set; }
        public string modelHash { get; set; }
        public int locked { get; set; }
        public string doorGroup { get; set; }
        public int lockIndex { get; set; }
    }
}
