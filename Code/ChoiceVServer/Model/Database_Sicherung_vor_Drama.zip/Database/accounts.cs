﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class accounts
    {
        public int id { get; set; }
        public string name { get; set; }
        public string socialclubName { get; set; }
        public string password { get; set; }
        public string salt { get; set; }
        public int state { get; set; }
        public string stateReason { get; set; }
        public int failedLogins { get; set; }
        public int adminLevel { get; set; }
        public int charAmount { get; set; }
        public int strikes { get; set; }
        public string serial { get; set; }
        public string lastIp { get; set; }
        public string registerIp { get; set; }
        public string lastLogin { get; set; }
        public string email { get; set; }
        public string licenseHash { get; set; }
    }
}
