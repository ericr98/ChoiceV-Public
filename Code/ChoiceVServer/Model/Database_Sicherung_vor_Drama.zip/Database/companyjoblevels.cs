﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class companyjoblevels
    {
        public companyjoblevels()
        {
            companyemployees = new HashSet<companyemployees>();
            companyjoblevelstopermissions = new HashSet<companyjoblevelstopermissions>();
        }

        public int id { get; set; }
        public int? companyId { get; set; }
        public string description { get; set; }
        public decimal? standartSalary { get; set; }
        public string name { get; set; }
        public int? isStandart { get; set; }
        public int isCEO { get; set; }

        public virtual companies company { get; set; }
        public virtual ICollection<companyemployees> companyemployees { get; set; }
        public virtual ICollection<companyjoblevelstopermissions> companyjoblevelstopermissions { get; set; }
    }
}
