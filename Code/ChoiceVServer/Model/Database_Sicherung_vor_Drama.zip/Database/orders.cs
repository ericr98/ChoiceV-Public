﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class orders
    {
        public int orderId { get; set; }
        public int elementId { get; set; }
        public int amount { get; set; }
        public int orderBy { get; set; }
        public DateTime orderDateTime { get; set; }
        public DateTime deliveryDateTime { get; set; }
        public sbyte arrivalMessageSent { get; set; }
        public sbyte pickedUp { get; set; }
        public int orderedAtCompanyId { get; set; }
        public long phoneNumber { get; set; }
    }
}
