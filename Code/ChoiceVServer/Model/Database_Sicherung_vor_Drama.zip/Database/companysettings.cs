﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class companysettings
    {
        public int id { get; set; }
        public int? companyId { get; set; }
        public string settingsName { get; set; }
        public string settingsValue { get; set; }

        public virtual companies company { get; set; }
    }
}
