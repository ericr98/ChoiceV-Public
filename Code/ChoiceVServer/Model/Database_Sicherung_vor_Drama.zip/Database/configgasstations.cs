﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configgasstations
    {
        public configgasstations()
        {
            configgasstationspots = new HashSet<configgasstationspots>();
        }

        public int id { get; set; }
        public string name { get; set; }
        public int type { get; set; }
        public int ownerType { get; set; }
        public int ownerId { get; set; }
        public string ownerName { get; set; }
        public float PricePetrol { get; set; }
        public float PriceDiesel { get; set; }
        public float PriceKerosene { get; set; }
        public float PriceGas { get; set; }
        public float PriceElectricity { get; set; }
        public float PriceAlternative { get; set; }

        public virtual ICollection<configgasstationspots> configgasstationspots { get; set; }
    }
}
