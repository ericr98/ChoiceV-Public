﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class characterinjuries
    {
        public int id { get; set; }
        public int charId { get; set; }
        public int bodyPart { get; set; }
        public int damage { get; set; }
        public int damageType { get; set; }
        public int isHealed { get; set; }
        public int? configInjury { get; set; }
        public int? isTreated { get; set; }
        public int seed { get; set; }

        public virtual characters _char { get; set; }
        public virtual configinjuries configInjuryNavigation { get; set; }
    }
}
