﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configmaterialdistributionspots
    {
        public int id { get; set; }
        public string showName { get; set; }
        public int companyId { get; set; }
        public string position { get; set; }
        public float width { get; set; }
        public float height { get; set; }
        public float rotation { get; set; }

        public virtual companies company { get; set; }
    }
}
