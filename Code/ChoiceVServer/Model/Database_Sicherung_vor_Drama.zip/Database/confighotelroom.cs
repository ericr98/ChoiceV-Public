﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class confighotelroom
    {
        public int id { get; set; }
        public string doorGroup { get; set; }
        public int? doorId { get; set; }
        public int roomtype { get; set; }
        public int roomclass { get; set; }
        public string roomname { get; set; }
        public string lockreason { get; set; }
        public int? islocked { get; set; }
        public int ingameroomtype { get; set; }
        public string teleportposition { get; set; }
        public int roomacceptsguests { get; set; }
        public int? dimension { get; set; }
    }
}
