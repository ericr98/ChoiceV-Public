﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configcollectjobtasks
    {
        public int id { get; set; }
        public int type { get; set; }
        public int jobId { get; set; }
        public string position { get; set; }
        public string rotation { get; set; }
        public string model { get; set; }
        public int animationId { get; set; }
        public string infoString { get; set; }
        public float colShapeHeight { get; set; }
        public float colShapeWidth { get; set; }
        public float colShapeRotation { get; set; }
        public string colShapePosition { get; set; }

        public virtual configanimations animation { get; set; }
    }
}
