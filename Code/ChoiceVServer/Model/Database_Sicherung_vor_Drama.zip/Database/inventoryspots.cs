﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class inventoryspots
    {
        public int id { get; set; }
        public int type { get; set; }
        public int inventoryId { get; set; }
        public string name { get; set; }
        public float width { get; set; }
        public float height { get; set; }
        public float rotation { get; set; }
        public string combination { get; set; }
        public DateTime createDate { get; set; }
        public string objectModel { get; set; }
        public string objectPosition { get; set; }
        public string objectRotation { get; set; }
        public string animationIdentifier { get; set; }
        public string position { get; set; }
    }
}
