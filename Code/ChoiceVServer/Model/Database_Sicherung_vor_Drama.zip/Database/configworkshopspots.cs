﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configworkshopspots
    {
        public int id { get; set; }
        public int workshopId { get; set; }
        public int spotType { get; set; }
        public string position { get; set; }
        public string rotation { get; set; }
        public float width { get; set; }
        public float height { get; set; }

        public virtual configworkshops workshop { get; set; }
    }
}
