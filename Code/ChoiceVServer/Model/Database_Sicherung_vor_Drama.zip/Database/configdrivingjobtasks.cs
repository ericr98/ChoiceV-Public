﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configdrivingjobtasks
    {
        public int id { get; set; }
        public int type { get; set; }
        public int jobId { get; set; }
        public string from { get; set; }
        public string to { get; set; }
        public string infoString { get; set; }
    }
}
