﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configordermarketgarages
    {
        public int companyId { get; set; }
        public int garageId { get; set; }
        public string vehicleClass { get; set; }
    }
}
