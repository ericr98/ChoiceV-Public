﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class characters
    {
        public characters()
        {
            characterdata = new HashSet<characterdata>();
            characterinjuries = new HashSet<characterinjuries>();
            charactertattoos = new HashSet<charactertattoos>();
            companyemployees = new HashSet<companyemployees>();
        }

        public int id { get; set; }
        public string bankaccount { get; set; }
        public int accountId { get; set; }
        public string firstname { get; set; }
        public string lastname { get; set; }
        public int age { get; set; }
        public double hunger { get; set; }
        public double thirst { get; set; }
        public double energy { get; set; }
        public int health { get; set; }
        public DateTime birthdate { get; set; }
        public int dead { get; set; }
        public string position { get; set; }
        public string rotation { get; set; }
        public string gender { get; set; }
        public string jobData { get; set; }
        public decimal cash { get; set; }
        public int state { get; set; }
        public DateTime? stateUpdateDate { get; set; }
        public long socialSecurityNumber { get; set; }

        public virtual characterclothings characterclothings { get; set; }
        public virtual charactersettings charactersettings { get; set; }
        public virtual characterstyles characterstyles { get; set; }
        public virtual ICollection<characterdata> characterdata { get; set; }
        public virtual ICollection<characterinjuries> characterinjuries { get; set; }
        public virtual ICollection<charactertattoos> charactertattoos { get; set; }
        public virtual ICollection<companyemployees> companyemployees { get; set; }
    }
}
