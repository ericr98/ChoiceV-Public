﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class gangphonenumbers
    {
        public int gangId { get; set; }
        public long phonenumber1 { get; set; }
        public long phonenumber2 { get; set; }
        public long phonenumber3 { get; set; }
        public long phonenumber4 { get; set; }
        public long phonenumber5 { get; set; }
    }
}
