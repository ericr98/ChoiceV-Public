﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configbeds
    {
        public string modelHash { get; set; }
        public float yOffset { get; set; }
        public float xOffset { get; set; }
        public float zOffset { get; set; }
        public float? rotationOffset { get; set; }
        public int? animation { get; set; }

        public virtual configanimations animationNavigation { get; set; }
    }
}
