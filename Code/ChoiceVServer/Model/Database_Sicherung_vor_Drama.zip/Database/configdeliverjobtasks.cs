﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configdeliverjobtasks
    {
        public int id { get; set; }
        public int type { get; set; }
        public int jobId { get; set; }
        public string position { get; set; }
        public int configItem { get; set; }
        public decimal bonus { get; set; }
        public int animationId { get; set; }
        public string infoString { get; set; }

        public virtual configanimations animation { get; set; }
        public virtual configitems configItemNavigation { get; set; }
        public virtual configminijobs job { get; set; }
    }
}
