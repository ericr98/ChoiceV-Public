﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configemergencycalltypetocompanies
    {
        public int calltype { get; set; }
        public int companyid { get; set; }
    }
}
