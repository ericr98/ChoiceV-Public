﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class characterclothings
    {
        public int characterid { get; set; }
        public int mask_drawable { get; set; }
        public int mask_texture { get; set; }
        public int torso_drawable { get; set; }
        public int torso_texture { get; set; }
        public int top_drawable { get; set; }
        public int top_texture { get; set; }
        public int shirt_drawable { get; set; }
        public int shirt_texture { get; set; }
        public int legs_drawable { get; set; }
        public int legs_texture { get; set; }
        public int feet_drawable { get; set; }
        public int feet_texture { get; set; }
        public int bag_drawable { get; set; }
        public int bag_texture { get; set; }
        public int accessoire_drawable { get; set; }
        public int accessoire_texture { get; set; }
        public int armor_drawable { get; set; }
        public int armor_texture { get; set; }
        public int hat_drawable { get; set; }
        public int hat_texture { get; set; }
        public int glasses_drawable { get; set; }
        public int glasses_texture { get; set; }
        public int ears_drawable { get; set; }
        public int ears_texture { get; set; }
        public int watches_drawable { get; set; }
        public int watches_texture { get; set; }
        public int bracelets_drawable { get; set; }
        public int bracelets_texture { get; set; }

        public virtual characters character { get; set; }
    }
}
