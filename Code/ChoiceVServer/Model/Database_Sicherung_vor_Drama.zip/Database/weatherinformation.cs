﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class weatherinformation
    {
        public DateTime start { get; set; }
        public int current { get; set; }
        public float mixPercent { get; set; }
        public int currentWeather { get; set; }
        public string currentWeatherName { get; set; }
        public int previousWeather { get; set; }
        public string previousWeatherName { get; set; }
        public DateTime nextChange { get; set; }
    }
}
