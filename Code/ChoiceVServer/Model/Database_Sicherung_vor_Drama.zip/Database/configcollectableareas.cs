﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configcollectableareas
    {
        public configcollectableareas()
        {
            configcollectableareapoints = new HashSet<configcollectableareapoints>();
        }

        public int id { get; set; }
        public string name { get; set; }
        public string type { get; set; }
        public int maxCollectables { get; set; }
        public int spawnDelay { get; set; }

        public virtual ICollection<configcollectableareapoints> configcollectableareapoints { get; set; }
    }
}
