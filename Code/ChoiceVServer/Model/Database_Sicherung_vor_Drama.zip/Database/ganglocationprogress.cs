﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class ganglocationprogress
    {
        public int gangid { get; set; }
        public int northside { get; set; }
        public int eastside { get; set; }
        public int southside { get; set; }
        public int westside { get; set; }
        public int sandyshores { get; set; }
        public int paletobay { get; set; }
    }
}
