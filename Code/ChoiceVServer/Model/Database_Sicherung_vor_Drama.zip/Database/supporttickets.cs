﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class supporttickets
    {
        public int id { get; set; }
        public int playerId { get; set; }
        public string playersocialClub { get; set; }
        public string nearPlayerIds { get; set; }
        public string nearPlayerSocialClubs { get; set; }
        public string description { get; set; }
        public DateTime date { get; set; }
        public string position { get; set; }
    }
}
