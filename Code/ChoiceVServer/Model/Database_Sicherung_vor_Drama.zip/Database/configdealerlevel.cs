﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configdealerlevel
    {
        public int level { get; set; }
        public int gangneededxp { get; set; }
        public int dealerneededxp { get; set; }
    }
}
