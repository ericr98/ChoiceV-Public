﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class companyjoblevelstopermissions
    {
        public int joblevelId { get; set; }
        public string permissionId { get; set; }

        public virtual companyjoblevels joblevel { get; set; }
        public virtual companypermissions permission { get; set; }
    }
}
