﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class companyemployees
    {
        public int id { get; set; }
        public int companyId { get; set; }
        public int charId { get; set; }
        public string charName { get; set; }
        public int jobLevelId { get; set; }
        public TimeSpan todayDuty { get; set; }
        public decimal salary { get; set; }
        public long selectedBankAccount { get; set; }
        public string companyemployeescol { get; set; }
        public long selectedPhoneNumer { get; set; }

        public virtual characters _char { get; set; }
        public virtual companies company { get; set; }
        public virtual companyjoblevels jobLevel { get; set; }
    }
}
