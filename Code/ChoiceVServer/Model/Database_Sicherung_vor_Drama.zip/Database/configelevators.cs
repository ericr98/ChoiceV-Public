﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configelevators
    {
        public int id { get; set; }
        public string name { get; set; }
        public string inColPosition { get; set; }
        public float inColWidth { get; set; }
        public float inColHeight { get; set; }
        public float inColRotation { get; set; }
    }
}
