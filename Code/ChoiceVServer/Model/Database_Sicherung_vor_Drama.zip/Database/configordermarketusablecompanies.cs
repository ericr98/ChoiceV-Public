﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configordermarketusablecompanies
    {
        public int MarketCompanyId { get; set; }
        public int CompanyId { get; set; }
        public sbyte? IsInclude { get; set; }
    }
}
