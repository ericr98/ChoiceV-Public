﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class confighotelbuilding
    {
        public int id { get; set; }
        public string name { get; set; }
        public int? hoteltype { get; set; }
        public int? ownerid { get; set; }
        public int? isautomated { get; set; }
        public int? hotelstars { get; set; }
        public string doorGroup { get; set; }
        public int? doorId { get; set; }
        public int? islocked { get; set; }
        public string lockreason { get; set; }
        public long bankAccountId { get; set; }
        public string building_position { get; set; }
        public float? building_width { get; set; }
        public float? building_height { get; set; }
        public float? building_rotation { get; set; }
        public string dropout_position { get; set; }
        public long phonenumber { get; set; }
    }
}
