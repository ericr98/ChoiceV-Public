﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class items
    {
        public items()
        {
            itemsdata = new HashSet<itemsdata>();
        }

        public int id { get; set; }
        public int configId { get; set; }
        public int inventoryId { get; set; }
        public int quality { get; set; }
        public DateTime? durability { get; set; }
        public int? wear { get; set; }
        public int? amount { get; set; }
        public string description { get; set; }

        public virtual configitems config { get; set; }
        public virtual inventories inventory { get; set; }
        public virtual ICollection<itemsdata> itemsdata { get; set; }
    }
}
