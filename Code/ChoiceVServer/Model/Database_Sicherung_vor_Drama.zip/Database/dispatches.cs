﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class dispatches
    {
        public int id { get; set; }
        public DateTime time { get; set; }
        public int type { get; set; }
        public string position { get; set; }
        public sbyte ended { get; set; }
        public int charId { get; set; }
        public string message { get; set; }
    }
}
