﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class inventories
    {
        public inventories()
        {
            items = new HashSet<items>();
        }

        public int id { get; set; }
        public int ownerId { get; set; }
        public float maxWeight { get; set; }
        public int inventoryType { get; set; }

        public virtual ICollection<items> items { get; set; }
    }
}
