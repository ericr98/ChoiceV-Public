﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class characterskills
    {
        public int id { get; set; }
        public int? charid { get; set; }
        public int configskill { get; set; }
        public double value { get; set; }
    }
}
