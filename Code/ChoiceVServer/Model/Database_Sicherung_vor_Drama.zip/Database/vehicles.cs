﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class vehicles
    {
        public int id { get; set; }
        public DateTime createDate { get; set; }
        public int modelId { get; set; }
        public int ownerId { get; set; }
        public string ownerName { get; set; }
        public int ownerType { get; set; }
        public string ownerHistory { get; set; }
        public int garageId { get; set; }
        public string position { get; set; }
        public string rotation { get; set; }
        public int dimension { get; set; }
        public string lastMoved { get; set; }
        public string numberPlate { get; set; }
        public string registeredPlate { get; set; }
        public string chassisNumber { get; set; }
        public float fuel { get; set; }
        public float drivenDistance { get; set; }
        public float drivenTime { get; set; }
        public int repairCount { get; set; }
        public int loadLate { get; set; }
        public int Locked { get; set; }

        public virtual vehiclescoloring vehiclescoloring { get; set; }
        public virtual vehiclesdamage vehiclesdamage { get; set; }
        public virtual vehiclestuning vehiclestuning { get; set; }
    }
}
