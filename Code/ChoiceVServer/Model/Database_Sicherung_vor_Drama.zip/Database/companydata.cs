﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class companydata
    {
        public int companyId { get; set; }
        public string dataName { get; set; }
        public string dataValue { get; set; }

        public virtual companies company { get; set; }
    }
}
