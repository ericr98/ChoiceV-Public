﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configemergencycallcenterevents
    {
        public int eventId { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public string rightinfo { get; set; }
        public string _event { get; set; }
    }
}
