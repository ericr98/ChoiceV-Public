﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configskills
    {
        public int id { get; set; }
        public string name { get; set; }
        public double growth { get; set; }
    }
}
