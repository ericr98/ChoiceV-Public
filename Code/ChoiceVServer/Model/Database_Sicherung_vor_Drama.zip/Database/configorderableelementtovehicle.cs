﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configorderableelementtovehicle
    {
        public int elementId { get; set; }
        public int vehicleModelId { get; set; }
    }
}
