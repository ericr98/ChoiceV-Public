﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configworkshops
    {
        public configworkshops()
        {
            configworkshopspots = new HashSet<configworkshopspots>();
        }

        public int id { get; set; }
        public string name { get; set; }
        public int type { get; set; }
        public int ownerType { get; set; }
        public int ownerId { get; set; }
        public string ownerName { get; set; }
        public string position { get; set; }
        public string rotation { get; set; }
        public int inventoryId { get; set; }

        public virtual ICollection<configworkshopspots> configworkshopspots { get; set; }
    }
}
