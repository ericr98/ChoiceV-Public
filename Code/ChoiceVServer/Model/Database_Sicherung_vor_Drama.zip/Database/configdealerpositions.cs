﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configdealerpositions
    {
        public int id { get; set; }
        public int? dealerid { get; set; }
        public string position { get; set; }
        public int heading { get; set; }
        public string positioninfo { get; set; }
    }
}
