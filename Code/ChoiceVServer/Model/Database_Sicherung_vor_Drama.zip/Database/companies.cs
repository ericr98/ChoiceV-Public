﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class companies
    {
        public companies()
        {
            companydata = new HashSet<companydata>();
            companyemployees = new HashSet<companyemployees>();
            companyjoblevels = new HashSet<companyjoblevels>();
            companylogs = new HashSet<companylogs>();
            companysettings = new HashSet<companysettings>();
            configmaterialdistributionspots = new HashSet<configmaterialdistributionspots>();
        }

        public int id { get; set; }
        public string name { get; set; }
        public string companyCity { get; set; }
        public string companyStreet { get; set; }
        public float companyTax { get; set; }
        public int companyType { get; set; }
        public long companyBankAccount { get; set; }
        public int reputation { get; set; }
        public int riskLevel { get; set; }
        public int buildingType { get; set; }
        public string position { get; set; }
        public int? blipType { get; set; }
        public int? blipColor { get; set; }
        public int maxEmployees { get; set; }
        public string codeCompany { get; set; }
        public int invoiceId { get; set; }

        public virtual ICollection<companydata> companydata { get; set; }
        public virtual ICollection<companyemployees> companyemployees { get; set; }
        public virtual ICollection<companyjoblevels> companyjoblevels { get; set; }
        public virtual ICollection<companylogs> companylogs { get; set; }
        public virtual ICollection<companysettings> companysettings { get; set; }
        public virtual ICollection<configmaterialdistributionspots> configmaterialdistributionspots { get; set; }
    }
}
