﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configdispatchtypelastingtime
    {
        public int type { get; set; }
        public int lastingtimeminutes { get; set; }
    }
}
