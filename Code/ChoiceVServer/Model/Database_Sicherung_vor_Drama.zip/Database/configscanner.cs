﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configscanner
    {
        public int id { get; set; }
        public string position { get; set; }
        public float width { get; set; }
        public float height { get; set; }
        public float rotation { get; set; }
    }
}
