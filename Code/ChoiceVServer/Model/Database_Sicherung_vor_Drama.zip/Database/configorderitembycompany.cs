﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configorderitembycompany
    {
        public int orderableItemId { get; set; }
        public int companyId { get; set; }
    }
}
