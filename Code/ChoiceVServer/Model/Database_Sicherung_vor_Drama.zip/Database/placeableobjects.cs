﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class placeableobjects
    {
        public int id { get; set; }
        public string objectModel { get; set; }
        public string position { get; set; }
        public string rotation { get; set; }
        public float? colWidth { get; set; }
        public float? colHeight { get; set; }
        public int? trackVehicles { get; set; }
        public DateTime createDate { get; set; }
        public string data { get; set; }
        public string codeItem { get; set; }
    }
}
