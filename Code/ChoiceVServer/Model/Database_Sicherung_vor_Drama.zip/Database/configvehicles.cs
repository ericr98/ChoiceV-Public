﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configvehicles
    {
        public int id { get; set; }
        public string name { get; set; }
        public int modelId { get; set; }
        public int classId { get; set; }
    }
}
