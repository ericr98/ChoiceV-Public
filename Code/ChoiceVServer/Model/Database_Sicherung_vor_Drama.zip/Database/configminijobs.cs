﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configminijobs
    {
        public configminijobs()
        {
            configdeliverjobtasks = new HashSet<configdeliverjobtasks>();
        }

        public int id { get; set; }
        public int type { get; set; }
        public int jobId { get; set; }
        public string name { get; set; }
        public string description { get; set; }
        public decimal reward { get; set; }
        public int maxState { get; set; }
        public string objectProp { get; set; }
        public string offset { get; set; }
        public string roation { get; set; }
        public string bone { get; set; }
        public string finishInfo { get; set; }
        public int noOrder { get; set; }
        public int? garadeId { get; set; }
        public string position { get; set; }

        public virtual ICollection<configdeliverjobtasks> configdeliverjobtasks { get; set; }
    }
}
