﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class vehiclescoloring
    {
        public int vehicleId { get; set; }
        public string appearanceData { get; set; }
        public int IsPrimaryColorRGBA { get; set; }
        public string PrimaryColorRGBA { get; set; }
        public int IsSecondaryColorRGBA { get; set; }
        public string SecondaryColorRGBA { get; set; }
        public int PrimaryColor { get; set; }
        public int SecondaryColor { get; set; }
        public int PearlColor { get; set; }
        public int WheelColor { get; set; }
        public int Livery { get; set; }
        public int RoofLivery { get; set; }
        public int ModColor1Type { get; set; }
        public int ModColor1 { get; set; }
        public int ModColor2Type { get; set; }
        public int ModColor2 { get; set; }
        public int Sanded1 { get; set; }
        public int Sanded2 { get; set; }
        public int Sanded3 { get; set; }

        public virtual vehicles vehicle { get; set; }
    }
}
