﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configorderableelementtoitem
    {
        public int elementId { get; set; }
        public int itemId { get; set; }
    }
}
