﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configweapondamage
    {
        public string weaponint { get; set; }
        public float damage { get; set; }
        public string weapon { get; set; }
    }
}
