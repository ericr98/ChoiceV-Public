﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class banktransactions
    {
        public int id { get; set; }
        public long fromAccount { get; set; }
        public long toAccount { get; set; }
        public decimal amount { get; set; }
        public DateTime transactionDate { get; set; }
        public DateTime transactionDelay { get; set; }
        public sbyte started { get; set; }
        public sbyte finished { get; set; }
        public string message { get; set; }
    }
}
