﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class vehiclesseat
    {
        public int id { get; set; }
        public DateTime createDate { get; set; }
        public int ModelId { get; set; }
        public int SeatNr { get; set; }
        public string SeatPos { get; set; }

        public virtual vehiclesmodel Model { get; set; }
    }
}
