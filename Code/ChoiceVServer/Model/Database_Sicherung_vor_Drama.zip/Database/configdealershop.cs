﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configdealershop
    {
        public int id { get; set; }
        public int neededganglevel { get; set; }
        public int configitemid { get; set; }
        public int amount { get; set; }
        public int neededdealerlevel { get; set; }
        public int dealersell { get; set; }
        public int pepesell { get; set; }
        public float price { get; set; }
        public int deliverytime { get; set; }
    }
}
