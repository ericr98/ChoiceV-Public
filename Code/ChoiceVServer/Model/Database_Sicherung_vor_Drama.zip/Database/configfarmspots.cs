﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configfarmspots
    {
        public int id { get; set; }
        public int farmid { get; set; }
        public string position { get; set; }
        public float radius { get; set; }
        public int currentamount { get; set; }
        public string nextrefill { get; set; }
    }
}
