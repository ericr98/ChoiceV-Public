﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class vehiclestuning
    {
        public int vehicleId { get; set; }
        public string appearanceData { get; set; }
        public int ModCount { get; set; }
        public float PowerMultiplier { get; set; }
        public float MaxSpeed { get; set; }
        public int Spoilers { get; set; }
        public int FrontBumper { get; set; }
        public int RearBumper { get; set; }
        public int SideSkirt { get; set; }
        public int Exhaust { get; set; }
        public int Frame { get; set; }
        public int Grille { get; set; }
        public int Hood { get; set; }
        public int Fender { get; set; }
        public int RightFender { get; set; }
        public int Roof { get; set; }
        public int Engine { get; set; }
        public int Brakes { get; set; }
        public int Transmission { get; set; }
        public int Horns { get; set; }
        public int Suspension { get; set; }
        public int Armor { get; set; }
        public int Turbo { get; set; }
        public int Xenon { get; set; }
        public int FrontWheels { get; set; }
        public int BackWheels { get; set; }
        public int PlateHolders { get; set; }
        public int TrimDesign { get; set; }
        public int Ornaments { get; set; }
        public int DialDesign { get; set; }
        public int SteeringWheel { get; set; }
        public int ShiftLever { get; set; }
        public int Plaques { get; set; }
        public int Hydraulics { get; set; }
        public int Boost { get; set; }
        public int Livery { get; set; }
        public int Plate { get; set; }
        public int Color1 { get; set; }
        public int Color2 { get; set; }
        public int DashboardColor { get; set; }
        public int InteriorColor { get; set; }
        public int TrimColor { get; set; }
        public int VanityPlates { get; set; }
        public int DoorSpeaker { get; set; }
        public int Seats { get; set; }
        public int Speakers { get; set; }
        public int Trunk { get; set; }
        public int EngineBlock { get; set; }
        public int Struts { get; set; }
        public int ArchCover { get; set; }
        public int Aerials { get; set; }
        public int Trim { get; set; }
        public int Tank { get; set; }
        public int Windows { get; set; }
        public int WheelType { get; set; }
        public int WheelVariation { get; set; }
        public int IsTireSmokeColorCustom { get; set; }
        public string TireSmokeColor { get; set; }
        public int HeadlightColor { get; set; }
        public int WindowTint { get; set; }
        public int IsNeonActive { get; set; }
        public string NeonColor { get; set; }
        public int IllegalEngine { get; set; }
        public int IllegalTurbo { get; set; }
        public int IllegalExhaust { get; set; }
        public int IllegalTransmission { get; set; }
        public int IllegalBoost { get; set; }
        public string Extras { get; set; }

        public virtual vehicles vehicle { get; set; }
    }
}
