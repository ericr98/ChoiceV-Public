﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class gangorders
    {
        public int orderid { get; set; }
        public int dealerid { get; set; }
        public int pepe { get; set; }
        public DateTime deliverdate { get; set; }
        public int gangid { get; set; }
        public int itemid { get; set; }
        public int amount { get; set; }
    }
}
