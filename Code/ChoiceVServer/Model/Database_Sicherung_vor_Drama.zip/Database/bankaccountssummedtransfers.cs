﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class bankaccountssummedtransfers
    {
        public long bankaccountid { get; set; }
        public decimal transfersDaily { get; set; }
        public decimal transfersWeekly { get; set; }
        public decimal cashwithdrawDaily { get; set; }
        public decimal cashwithdrawWeekly { get; set; }
        public sbyte reported_td { get; set; }
        public sbyte reported_tw { get; set; }
        public sbyte reported_cd { get; set; }
        public sbyte reported_cw { get; set; }
    }
}
