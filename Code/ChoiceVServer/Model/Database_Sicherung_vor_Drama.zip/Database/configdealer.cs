﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configdealer
    {
        public int id { get; set; }
        public string dealername { get; set; }
        public string dealerped { get; set; }
        public int gangflag { get; set; }
        public int xpprogress { get; set; }
        public int currentlevel { get; set; }
        public int inventoryid { get; set; }
        public long phonenumber { get; set; }
    }
}
