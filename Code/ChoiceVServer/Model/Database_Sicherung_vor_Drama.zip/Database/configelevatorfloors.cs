﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configelevatorfloors
    {
        public int elevatorId { get; set; }
        public int level { get; set; }
        public float portZ { get; set; }
        public int door1Id { get; set; }
        public int door2Id { get; set; }
        public string callCollPos { get; set; }
        public float callCollHeight { get; set; }
        public float callCollWidth { get; set; }
        public float callCollRotation { get; set; }
    }
}
