﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configordersystem
    {
        public string key { get; set; }
        public string value { get; set; }
    }
}
