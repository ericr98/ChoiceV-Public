﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class placedbackpacks
    {
        public int id { get; set; }
        public string position { get; set; }
        public int inventoryId { get; set; }
        public float yaw { get; set; }
    }
}
