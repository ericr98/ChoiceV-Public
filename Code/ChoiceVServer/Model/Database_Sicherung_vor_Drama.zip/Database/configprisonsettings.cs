﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configprisonsettings
    {
        public string key { get; set; }
        public string value { get; set; }
    }
}
