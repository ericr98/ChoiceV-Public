﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configdealerspecialitem
    {
        public int dealerid { get; set; }
        public int itemid { get; set; }
        public int itemamount { get; set; }
        public int percentage { get; set; }
    }
}
