﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class confighotelroomrate
    {
        public int id { get; set; }
        public int hotelid { get; set; }
        public int roomtype { get; set; }
        public int roomclass { get; set; }
        public decimal rate { get; set; }
        public int ratetickindays { get; set; }
    }
}
