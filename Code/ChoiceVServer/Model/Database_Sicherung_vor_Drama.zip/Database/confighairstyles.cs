﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class confighairstyles
    {
        public int id { get; set; }
        public string name { get; set; }
        public decimal cost { get; set; }
        public int gtaId { get; set; }
        public int male { get; set; }
    }
}
