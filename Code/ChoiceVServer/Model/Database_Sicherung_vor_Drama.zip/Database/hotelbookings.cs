﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class hotelbookings
    {
        public int id { get; set; }
        public int roomid { get; set; }
        public int guestid { get; set; }
        public DateTime startdate { get; set; }
        public DateTime? enddate { get; set; }
        public decimal currentrate { get; set; }
        public sbyte bookingEnded { get; set; }
        public long phoneNumber { get; set; }
        public long socialSecurityNumber { get; set; }
    }
}
