﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configitems
    {
        public configitems()
        {
            configdeliverjobtasks = new HashSet<configdeliverjobtasks>();
            configinjuriestoitems = new HashSet<configinjuriestoitems>();
            configinteractionpositions = new HashSet<configinteractionpositions>();
            configshopitems = new HashSet<configshopitems>();
            configweedtypes = new HashSet<configweedtypes>();
            items = new HashSet<items>();
        }

        public int configItemId { get; set; }
        public int subItemId { get; set; }
        public int subItemAmount { get; set; }
        public string name { get; set; }
        public string category { get; set; }
        public int durability { get; set; }
        public int destroyedWhenUsed { get; set; }
        public int detectable { get; set; }
        public float weight { get; set; }
        public double thirst { get; set; }
        public double energy { get; set; }
        public int refrigerateDurability { get; set; }
        public int foodPoisoning { get; set; }
        public double hunger { get; set; }
        public int wear { get; set; }
        public int specialUse { get; set; }
        public string codeItem { get; set; }
        public string additionalInfo { get; set; }
        public int? itemAnimation { get; set; }
        public int itemType { get; set; }

        public virtual configitemanimations itemAnimationNavigation { get; set; }
        public virtual ICollection<configdeliverjobtasks> configdeliverjobtasks { get; set; }
        public virtual ICollection<configinjuriestoitems> configinjuriestoitems { get; set; }
        public virtual ICollection<configinteractionpositions> configinteractionpositions { get; set; }
        public virtual ICollection<configshopitems> configshopitems { get; set; }
        public virtual ICollection<configweedtypes> configweedtypes { get; set; }
        public virtual ICollection<items> items { get; set; }
    }
}
