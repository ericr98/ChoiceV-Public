﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class phonecontacts
    {
        public int id { get; set; }
        public long? ownerNumber { get; set; }
        public string name { get; set; }
        public string note { get; set; }
        public string email { get; set; }
        public int favorit { get; set; }
        public long number { get; set; }

        public virtual phonenumbers ownerNumberNavigation { get; set; }
    }
}
