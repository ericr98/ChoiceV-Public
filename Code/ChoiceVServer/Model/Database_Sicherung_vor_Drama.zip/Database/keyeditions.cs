﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class keyeditions
    {
        public int id { get; set; }
        public string doorgroupidentifier { get; set; }
        public int charId { get; set; }
        public string reason { get; set; }
        public int amount { get; set; }
    }
}
