﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class bankcashwithdrawrequests
    {
        public int id { get; set; }
        public long bankAccountId { get; set; }
        public decimal requestedCash { get; set; }
        public DateTime requestTime { get; set; }
        public sbyte requested { get; set; }
        public sbyte announced { get; set; }
    }
}
