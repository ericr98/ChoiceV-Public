﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class confighotelsettings
    {
        public int settingsid { get; set; }
        public string settingname { get; set; }
        public string settingvalue { get; set; }
    }
}
