﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configweapons
    {
        public string weaponName { get; set; }
        public string weaponType { get; set; }
        public string displayType { get; set; }
        public string attachObjectPosition { get; set; }
        public string attachObjectRotation { get; set; }
        public int? attachObjectBone { get; set; }
        public float damageMult { get; set; }
        public string attachObjectModel { get; set; }
        public string equipSlot { get; set; }
    }
}
