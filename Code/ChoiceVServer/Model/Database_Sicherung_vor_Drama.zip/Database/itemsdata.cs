﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class itemsdata
    {
        public int itemId { get; set; }
        public string parameter { get; set; }
        public string value { get; set; }

        public virtual items item { get; set; }
    }
}
