﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configweedtypes
    {
        public int id { get; set; }
        public string type { get; set; }
        public string itemType { get; set; }
        public int resultItemId { get; set; }

        public virtual configitems resultItem { get; set; }
    }
}
