﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configbuffs
    {
        public string name { get; set; }
        public float multiplier { get; set; }
        public int liveTime { get; set; }
        public string turnOnDescription { get; set; }
        public string runoutDescription { get; set; }
    }
}
