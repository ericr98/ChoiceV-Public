﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configcollectableareapoints
    {
        public int id { get; set; }
        public int areaId { get; set; }
        public float x { get; set; }
        public float y { get; set; }

        public virtual configcollectableareas area { get; set; }
    }
}
