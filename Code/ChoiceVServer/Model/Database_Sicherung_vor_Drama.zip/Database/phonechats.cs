﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class phonechats
    {
        public phonechats()
        {
            phonechatmessages = new HashSet<phonechatmessages>();
        }

        public int id { get; set; }
        public long number1 { get; set; }
        public long number2 { get; set; }

        public virtual phonenumbers number1Navigation { get; set; }
        public virtual phonenumbers number2Navigation { get; set; }
        public virtual ICollection<phonechatmessages> phonechatmessages { get; set; }
    }
}
