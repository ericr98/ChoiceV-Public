﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configatms
    {
        public int id { get; set; }
        public string position { get; set; }
        public string location { get; set; }
        public int showBlip { get; set; }
        public int company { get; set; }
        public double deposit { get; set; }
        public DateTime? lastHeistDate { get; set; }
        public float rotation { get; set; }
    }
}
