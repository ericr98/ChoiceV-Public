﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configmilos
    {
        public int id { get; set; }
        public string name { get; set; }
        public string miloname { get; set; }
        public float x { get; set; }
        public float y { get; set; }
        public int? blipType { get; set; }
        public int? blipColor { get; set; }
        public int? loadingState { get; set; }
    }
}
