﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configinjurytypes
    {
        public int id { get; set; }
        public int minPainLevel { get; set; }
        public int maxPainLevel { get; set; }
        public string displayName { get; set; }
        public int? operationId { get; set; }
    }
}
