﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class logpolicedooractions
    {
        public int id { get; set; }
        public int characterId { get; set; }
        public string characterName { get; set; }
        public int doorid { get; set; }
        public string position { get; set; }
        public string action { get; set; }
        public DateTime time { get; set; }
    }
}
