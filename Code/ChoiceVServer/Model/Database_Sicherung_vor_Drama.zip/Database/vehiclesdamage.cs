﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class vehiclesdamage
    {
        public int vehicleId { get; set; }
        public string healthData { get; set; }
        public string damageData { get; set; }
        public int bodyhealth { get; set; }
        public int bodyadditionalhealth { get; set; }
        public int petroltankhealth { get; set; }
        public float enginehealth { get; set; }
        public float dirtlevel { get; set; }
        public int bumperlevel_front { get; set; }
        public int bumperlevel_rear { get; set; }
        public int partlevel_frontleft { get; set; }
        public int partlevel_frontright { get; set; }
        public int partlevel_middleleft { get; set; }
        public int partlevel_middleright { get; set; }
        public int partlevel_rearleft { get; set; }
        public int partlevel_rearright { get; set; }
        public int partbullets_frontleft { get; set; }
        public int partbullets_frontright { get; set; }
        public int partbullets_middleleft { get; set; }
        public int partbullets_middleright { get; set; }
        public int partbullets_rearleft { get; set; }
        public int partbullets_rearright { get; set; }
        public int windowstate_front { get; set; }
        public int windowstate_back { get; set; }
        public int windowstate_frontleft { get; set; }
        public int windowstate_frontright { get; set; }
        public int windowstate_rearleft { get; set; }
        public int windowstate_rearright { get; set; }
        public float armoredwindow_front { get; set; }
        public float armoredwindow_back { get; set; }
        public float armoredwindow_frontleft { get; set; }
        public float armoredwindow_frontright { get; set; }
        public float armoredwindow_rearleft { get; set; }
        public float armoredwindow_rearright { get; set; }
        public int armoredwindowbullets_front { get; set; }
        public int armoredwindowbullets_back { get; set; }
        public int armoredwindowbullets_frontleft { get; set; }
        public int armoredwindowbullets_frontright { get; set; }
        public int armoredwindowbullets_rearleft { get; set; }
        public int armoredwindowbullets_rearright { get; set; }
        public int lightstate_frontleft { get; set; }
        public int lightstate_frontright { get; set; }
        public int lightstate_rearleft { get; set; }
        public int lightstate_rearright { get; set; }
        public int speziallightstate_frontleft { get; set; }
        public int speziallightstate_frontright { get; set; }
        public int speziallightstate_rearleft { get; set; }
        public int speziallightstate_rearright { get; set; }
        public int doorstate_frontleft { get; set; }
        public int doorstate_frontright { get; set; }
        public int doorstate_rearleft { get; set; }
        public int doorstate_rearright { get; set; }
        public int doorstate_hood { get; set; }
        public int doorstate_trunk { get; set; }
        public int doorstate_back { get; set; }
        public int doorstate_back2 { get; set; }
        public string wheelhastire { get; set; }
        public string wheeldetached { get; set; }
        public string wheelhealth { get; set; }
        public string wheelburst { get; set; }
        public int diagnosed { get; set; }
        public int reportid { get; set; }
        public string reportdata { get; set; }

        public virtual vehicles vehicle { get; set; }
    }
}
