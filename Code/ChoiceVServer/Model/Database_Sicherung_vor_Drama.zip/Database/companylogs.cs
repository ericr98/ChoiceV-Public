﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class companylogs
    {
        public int id { get; set; }
        public int? companyId { get; set; }
        public string logKey { get; set; }
        public string logMessage { get; set; }
        public DateTime? logDate { get; set; }

        public virtual companies company { get; set; }
    }
}
