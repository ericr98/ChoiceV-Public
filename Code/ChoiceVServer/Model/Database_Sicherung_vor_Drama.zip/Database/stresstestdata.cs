﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class stresstestdata
    {
        public int id { get; set; }
        public string platform { get; set; }
        public string discovered { get; set; }
        public string timestamp { get; set; }
        public string socialclub { get; set; }
        public string message { get; set; }
        public string age { get; set; }
        public string servers { get; set; }
        public string faction { get; set; }
    }
}
