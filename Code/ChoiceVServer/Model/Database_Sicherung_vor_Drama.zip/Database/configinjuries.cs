﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configinjuries
    {
        public configinjuries()
        {
            characterinjuries = new HashSet<characterinjuries>();
            configinjuriestoitems = new HashSet<configinjuriestoitems>();
        }

        public int id { get; set; }
        public string name { get; set; }
        public string bodyPart { get; set; }
        public string damageType { get; set; }
        public int minSeverness { get; set; }
        public int maxSeverness { get; set; }

        public virtual ICollection<characterinjuries> characterinjuries { get; set; }
        public virtual ICollection<configinjuriestoitems> configinjuriestoitems { get; set; }
    }
}
