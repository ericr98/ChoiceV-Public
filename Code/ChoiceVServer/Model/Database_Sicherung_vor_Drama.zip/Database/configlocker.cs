﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configlocker
    {
        public int id { get; set; }
        public string position { get; set; }
        public float width { get; set; }
        public float height { get; set; }
        public float rotation { get; set; }
        public int lockerid { get; set; }
        public int shopID { get; set; }
        public int locked2 { get; set; }
        public int locked3 { get; set; }
        public int locked4 { get; set; }
        public int locked5 { get; set; }
        public int amount { get; set; }
        public int inventoryId1 { get; set; }
        public int inventoryId2 { get; set; }
        public int inventoryId3 { get; set; }
        public int inventoryId4 { get; set; }
        public int inventoryId5 { get; set; }
        public string key1 { get; set; }
        public string key2 { get; set; }
        public string key3 { get; set; }
        public string key4 { get; set; }
        public string key5 { get; set; }
        public int locked1 { get; set; }
    }
}
