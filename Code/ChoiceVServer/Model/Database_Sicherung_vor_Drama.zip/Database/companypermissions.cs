﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class companypermissions
    {
        public companypermissions()
        {
            companyjoblevelstopermissions = new HashSet<companyjoblevelstopermissions>();
        }

        public string identifier { get; set; }
        public int companyType { get; set; }
        public string showName { get; set; }

        public virtual ICollection<companyjoblevelstopermissions> companyjoblevelstopermissions { get; set; }
    }
}
