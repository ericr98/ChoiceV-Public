﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configshopitems
    {
        public int shopType { get; set; }
        public int itemId { get; set; }
        public decimal price { get; set; }

        public virtual configitems item { get; set; }
    }
}
