﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class charactertattoos
    {
        public int characterId { get; set; }
        public int tattooId { get; set; }

        public virtual characters character { get; set; }
        public virtual configtattoos tattoo { get; set; }
    }
}
