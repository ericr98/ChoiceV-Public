﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configfarms
    {
        public int id { get; set; }
        public string name { get; set; }
        public int item { get; set; }
        public string position { get; set; }
        public int fertilizingactivated { get; set; }
        public float nitrogenlevel { get; set; }
        public float phosphoruslevel { get; set; }
        public float potashlevel { get; set; }
        public float waterlevel { get; set; }
        public int itemmaxregrow { get; set; }
        public string bestregrowtime { get; set; }
    }
}
