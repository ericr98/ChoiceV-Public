﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configinteractionpositions
    {
        public int id { get; set; }
        public string name { get; set; }
        public string position { get; set; }
        public string interactionEvent { get; set; }
        public int? neededTool { get; set; }
        public float width { get; set; }
        public float height { get; set; }
        public float rotation { get; set; }
        public int priority { get; set; }
        public string extraInfo { get; set; }
        public string comment { get; set; }
        public int? animation { get; set; }
        public int? itemAnimation { get; set; }

        public virtual configanimations animationNavigation { get; set; }
        public virtual configitemanimations itemAnimationNavigation { get; set; }
        public virtual configitems neededToolNavigation { get; set; }
    }
}
