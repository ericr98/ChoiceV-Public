﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class characterstyles
    {
        public int charId { get; set; }
        public string gender { get; set; }
        public float faceFather { get; set; }
        public float faceMother { get; set; }
        public int faceEyes { get; set; }
        public float faceFeature_0 { get; set; }
        public float faceFeature_1 { get; set; }
        public float faceFeature_10 { get; set; }
        public float faceFeature_11 { get; set; }
        public float faceFeature_12 { get; set; }
        public float faceFeature_13 { get; set; }
        public float faceFeature_14 { get; set; }
        public float faceFeature_15 { get; set; }
        public float faceFeature_16 { get; set; }
        public float faceFeature_17 { get; set; }
        public float faceFeature_18 { get; set; }
        public float faceFeature_2 { get; set; }
        public float faceFeature_3 { get; set; }
        public float faceFeature_4 { get; set; }
        public float faceFeature_5 { get; set; }
        public float faceFeature_6 { get; set; }
        public float faceFeature_7 { get; set; }
        public float faceFeature_8 { get; set; }
        public float faceFeature_9 { get; set; }
        public float faceShape { get; set; }
        public float faceSkin { get; set; }
        public int hairColor { get; set; }
        public int hairHighlight { get; set; }
        public int hairStyle { get; set; }
        public int overlay_0 { get; set; }
        public int overlay_1 { get; set; }
        public int overlay_10 { get; set; }
        public int overlay_11 { get; set; }
        public int overlay_12 { get; set; }
        public int overlay_2 { get; set; }
        public int overlay_3 { get; set; }
        public int overlay_4 { get; set; }
        public int overlay_5 { get; set; }
        public int overlay_6 { get; set; }
        public int overlay_7 { get; set; }
        public int overlay_8 { get; set; }
        public int overlay_9 { get; set; }
        public int overlaycolor_1 { get; set; }
        public int overlaycolor_10 { get; set; }
        public int overlaycolor_2 { get; set; }
        public int overlaycolor_5 { get; set; }
        public int overlaycolor_8 { get; set; }
        public int overlayhighlight_1 { get; set; }
        public int overlayhighlight_2 { get; set; }
        public int overlayhighlight_5 { get; set; }
        public int overlayhighlight_8 { get; set; }

        [JsonIgnore]
        public virtual characters _char { get; set; }
    }
}
