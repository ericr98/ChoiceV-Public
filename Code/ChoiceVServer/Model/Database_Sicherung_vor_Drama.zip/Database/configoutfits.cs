﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configoutfits
    {
        public string name { get; set; }
        public string gender { get; set; }
        public string info { get; set; }
        public string description { get; set; }
        public int torso_texture { get; set; }
        public int top_drawable { get; set; }
        public int top_texture { get; set; }
        public int shirt_drawable { get; set; }
        public int shirt_texture { get; set; }
        public int accessoire_drawable { get; set; }
        public int accessoire_texture { get; set; }
        public int legs_drawable { get; set; }
        public int legs_texture { get; set; }
        public int feet_drawable { get; set; }
        public int feet_texture { get; set; }
        public int? decal_drawable { get; set; }
        public int torso_drawable { get; set; }
        public int decal_texture { get; set; }
    }
}
