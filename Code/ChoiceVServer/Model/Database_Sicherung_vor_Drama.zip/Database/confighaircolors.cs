﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class confighaircolors
    {
        public int? id { get; set; }
        public string name { get; set; }
    }
}
