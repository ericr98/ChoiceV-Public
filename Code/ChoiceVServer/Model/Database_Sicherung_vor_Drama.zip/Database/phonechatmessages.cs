﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class phonechatmessages
    {
        public int id { get; set; }
        public int chatId { get; set; }
        public long from { get; set; }
        public string text { get; set; }
        public DateTime sendDate { get; set; }
        public int read { get; set; }

        public virtual phonechats chat { get; set; }
        public virtual phonenumbers fromNavigation { get; set; }
    }
}
