﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class evidence
    {
        public int id { get; set; }
        public int type { get; set; }
        public string position { get; set; }
        public DateTime dateTime { get; set; }
        public string data { get; set; }
    }
}
