﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class bankaccounts
    {
        public long id { get; set; }
        public int ownerId { get; set; }
        public string name { get; set; }
        public int pin { get; set; }
        public decimal balance { get; set; }
        public int frozen { get; set; }
        public int company { get; set; }
        public int accountType { get; set; }
        public decimal creditBalance { get; set; }
        public decimal creditPaymentRate { get; set; }
        public int creditPaymentsMissedDays { get; set; }
        public decimal historyBalance { get; set; }
        public DateTime creationDate { get; set; }
        public long phoneNumber { get; set; }
        public long? socialSecurityNumber { get; set; }
    }
}
