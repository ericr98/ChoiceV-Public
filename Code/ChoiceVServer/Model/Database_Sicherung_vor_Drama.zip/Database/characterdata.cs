﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class characterdata
    {
        public int charId { get; set; }
        public string name { get; set; }
        public string value { get; set; }

        public virtual characters _char { get; set; }
    }
}
