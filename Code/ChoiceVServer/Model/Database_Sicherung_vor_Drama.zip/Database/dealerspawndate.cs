﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class dealerspawndate
    {
        public int id { get; set; }
        public DateTime spawndate { get; set; }
        public DateTime despawndate { get; set; }
    }
}
