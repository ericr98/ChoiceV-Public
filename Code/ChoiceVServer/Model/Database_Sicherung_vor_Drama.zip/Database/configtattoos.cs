﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configtattoos
    {
        public configtattoos()
        {
            charactertattoos = new HashSet<charactertattoos>();
        }

        public int id { get; set; }
        public string CollectionName { get; set; }
        public string HashNameMale { get; set; }
        public string HashNameFemale { get; set; }
        public string Name { get; set; }
        public string LocalizedName { get; set; }
        public string Zone { get; set; }
        public int ZoneID { get; set; }

        public virtual ICollection<charactertattoos> charactertattoos { get; set; }
    }
}
