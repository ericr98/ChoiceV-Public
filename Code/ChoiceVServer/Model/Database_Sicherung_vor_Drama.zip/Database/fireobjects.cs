﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class fireobjects
    {
        public int id { get; set; }
        public DateTime createDate { get; set; }
        public string fireModel { get; set; }
        public float? fireSize { get; set; }
        public int? fireCount { get; set; }
        public int? childDelay { get; set; }
        public int? childSpread { get; set; }
        public string eventRunDate { get; set; }
        public string eventRunDays { get; set; }
        public string eventRunTime { get; set; }
        public int? eventRunPlayers { get; set; }
        public int? eventRunDepartment { get; set; }
        public DateTime eventDate { get; set; }
        public int? eventTimespan { get; set; }
        public int? eventRandomTime { get; set; }
        public int? eventMaxRunTime { get; set; }
        public int? eventActive { get; set; }
        public int? explosionPossible { get; set; }
        public int? explosionProbability { get; set; }
        public string position { get; set; }
        public string rotation { get; set; }
        public float? colWidth { get; set; }
        public float? colHeight { get; set; }
        public string codeItem { get; set; }
    }
}
