﻿using System;
using System.Collections.Generic;

namespace ChoiceVServer.Model.Database
{
    public partial class configbank
    {
        public int id { get; set; }
        public string name { get; set; }
        public int supportedAccountTypesFlag { get; set; }
        public int? transferFeePercentage { get; set; }
        public int? savingsInterestRatePercentage { get; set; }
        public decimal? transferLimit { get; set; }
        public decimal? payoutLimit { get; set; }
        public int? businessAccountFeePercentage { get; set; }
        public decimal? openingFeeAmmount { get; set; }
    }
}
